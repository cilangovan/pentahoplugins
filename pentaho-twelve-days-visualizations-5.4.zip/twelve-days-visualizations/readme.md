
# Twelve Days of Big Data Visualizations

12 Ways to examine your data like never before.

## Installation

Just place this plugin's folder in the server's "pentaho-solutions/system" folder.

v3.0