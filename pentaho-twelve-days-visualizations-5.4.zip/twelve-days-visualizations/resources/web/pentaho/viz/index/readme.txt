Index Chart

The chart indexes by the x-axis item the mouse is over. All the other x-axis items show their relative % compared to the indexing item.

Displays on IE, but interactivity does not work yet.
Does not support drill down
Has mouse-over interactivity
You can alter the background and the label font/color using the chart options dialog

V2
