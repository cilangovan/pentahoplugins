
# Calendar Visualization

The calendar visualization shows a dataset as a compressed Calendar view. 

V3.0
