Calendar

The calendar shows a data set as compressed Calendar view. 

