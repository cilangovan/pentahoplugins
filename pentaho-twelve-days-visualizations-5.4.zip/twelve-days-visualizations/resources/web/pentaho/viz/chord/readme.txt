Chord Chart

This chart is similar to the heat grid visualization. Except rounder...

Does not work on IE.
Probably does not support negative values.
Supports drill down
Has mouse-over highlighting
You can click to toggle selection of a group on/off
You can use the keep/exclude options
You can alter the background and the label font/color using the chart options dialog

V2