Packed Circle

The chart shows a hierarchy as a series of nested circles. 

