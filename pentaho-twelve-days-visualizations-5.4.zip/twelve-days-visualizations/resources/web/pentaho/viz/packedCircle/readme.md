
# Packed Circles Visualization 

This visualization shows a hierarchy as a series of nested circles.

V3.0