
# Parallel Coordinates Visualization

The visualization shows multiple measures on vertical (parallel) scales.
You can add multiple measures.
Works well with up to 6-8 measures depending on your screen resolution. 

Displays on IE, but interactivity does not work yet.
Does not support drill down.
Does support filtering.
You can click and drag to select items.
You can alter the background and the label font/color using the chart options dialog.

V3.0