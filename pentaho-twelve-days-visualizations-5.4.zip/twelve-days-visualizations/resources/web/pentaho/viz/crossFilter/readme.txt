Cross Filter

This shows each measure as a histogram and lets you filters the rows on each histogram

