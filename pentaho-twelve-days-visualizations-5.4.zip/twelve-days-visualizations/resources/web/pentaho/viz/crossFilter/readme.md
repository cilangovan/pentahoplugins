
# Cross Filter Visualization

This visualization shows each measure as a histogram and lets you filter the rows on each histogram.

V3.0
