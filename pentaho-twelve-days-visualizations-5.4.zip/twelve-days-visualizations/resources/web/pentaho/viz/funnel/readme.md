
# Funnel Visualization

This visualization shows a dataset as a series of funnel sections. 

v3.0
