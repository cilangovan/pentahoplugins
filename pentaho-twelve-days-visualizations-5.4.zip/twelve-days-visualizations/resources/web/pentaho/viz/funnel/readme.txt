Funnel

The chart shows a data set as a series of funnel sections. 

