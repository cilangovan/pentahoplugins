TagCloud

The "Mullet of the Internet". Shows a cloud of words with different sizes and colors.

V1.0