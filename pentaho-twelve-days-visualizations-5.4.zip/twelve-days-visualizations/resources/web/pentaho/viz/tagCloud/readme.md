
# Tag Cloud Visualization

The "Mullet of the Internet".
Shows a cloud of words with different sizes and colors.

V3.0