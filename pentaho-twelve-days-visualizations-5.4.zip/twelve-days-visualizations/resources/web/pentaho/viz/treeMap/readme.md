
# Tree Map Visualization

This visualization shows a hierarchy as a set of rectangles that fill the plot area.

V3.0