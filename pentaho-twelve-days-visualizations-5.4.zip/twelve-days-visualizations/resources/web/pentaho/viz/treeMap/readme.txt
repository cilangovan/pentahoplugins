Tree Map

The chart shows a hierarchy as a set of rectangles that fills the plot area.

V2