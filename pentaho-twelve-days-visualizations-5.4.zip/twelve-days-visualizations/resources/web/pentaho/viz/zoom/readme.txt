Zoom

This chart allows you to zoom/slide on the x-axis

V2.0