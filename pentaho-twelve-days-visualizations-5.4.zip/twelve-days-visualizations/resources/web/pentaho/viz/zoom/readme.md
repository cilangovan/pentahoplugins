
# Zoom Visualization

This visualization allows you to zoom/slide on the x-axis.

V3.0