
# Trellis Visualization

This visualization shows multiple scatter plots.
You can add multiple measures. 
Works well with up to 6-8 measures, depending on your screen resolution. 

Displays on IE, but interactivity does not work yet.
Does not support drill down or filtering.
You can click and drag to select points.
You can alter the background and the label font/color using the chart options dialog.

V3.0