
# Visualizations Configuration

You can enable or disable any of the visualizations provided in 
this plugin by editing the `vizTypes.json` file.

Enabled visualizations have a `1` value.
Disabled visualizations have a `0` value.

The `sunBurst` visualization is disabled by default 
because it has been superseeded by the corresponding Common-UI visualization.
